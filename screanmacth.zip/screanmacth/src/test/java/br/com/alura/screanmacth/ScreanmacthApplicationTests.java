package br.com.alura.screanmacth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreanmacthApplicationTests {

	@Test
	void contextLoads() {
	}

}
