package br.com.alura.screanmacth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScreanmacthApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScreanmacthApplication.class, args);
	}

}
